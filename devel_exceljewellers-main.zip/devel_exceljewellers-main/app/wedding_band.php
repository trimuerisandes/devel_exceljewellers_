<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wedding_band extends Model
{
    //
}
