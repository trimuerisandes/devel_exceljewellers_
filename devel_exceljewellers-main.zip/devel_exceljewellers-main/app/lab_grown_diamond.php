<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lab_grown_diamond extends Model
{
    //
}
