<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class engagement_ring extends Model
{
    //
}
