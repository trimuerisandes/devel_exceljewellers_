<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class j_vid extends Model
{
    //
}
