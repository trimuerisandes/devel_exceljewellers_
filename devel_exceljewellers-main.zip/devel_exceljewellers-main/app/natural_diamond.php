<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class natural_diamond extends Model
{
    //
}
