<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class return_product extends Model
{
    //
}
