<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fine_jewellery extends Model
{
    //
}
