
<div class="main-background" style="text-align: center !important;font-family: arial, sans-serif !important;">
<div class="back" style="background:white !important;padding: 80px 0px;">
	<div class="logo"><img src="https://www.exceljewellers.com/storage/image/page_img/excel_logo.png"></div>
</div>
<br>

<div style="height: 200px; overflow: hidden;">
	<img style="position: relative;bottom: 250px;" src="https://www.exceljewellers.com/storage/image/page_img/gab_page_img5.jpeg">
</div>

<br><br>

<div style="width: 400px;margin: auto;">Take OFF Your Next Purchase At <a style="color: #d60d8c !important;text-decoration: none;font-weight: bold;" href="https://www.exceljewellers.com/">Exceljewellers.com</a> Some Restrictions May Apply.</div>

<div class="order-container" style="padding: 20px 0px !important;">

	<div>USE CODE:</div>

	<div style="cursor: pointer !important; color:#d60d8c !important;font-size: 35px;font-weight: bold;padding: 5px;border: dotted 3px #d60d8c;border-radius: 4px;width: 400px !important;margin: 5px auto !important;">test123</div>

</div>



<div>

<div style="width: 100% !important; background:#d60d8c;">
	wersdfsf
</div>

</div>
</div>
