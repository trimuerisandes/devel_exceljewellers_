<div class="main-background" style="text-align: center !important;font-family: arial, sans-serif !important;">
<div class="back" style="background:white !important;padding: 10px 0px;">
  <div class="logo"><img style="height:400px;" src="https://www.beneplants.com/storage/image/page_img/banner.jpg"></div>
</div>
<br>
<div style="width: 450px;margin: auto;"><b>Thank You</b> for booking <b>Excel Jewellers</b> Verragio Bridal Show.
@if(isset($data['name']))
<div>Name: {{$data['name']}}</div>
<div>Email: {{$data['email']}}</div>
<div>Phone Number: {{$data['phone']}}</div>
<div>Time: {{$data['time']}}</div>
<br>
@else
<div>Just a reminder you are booked at {{$data['time']}} on Saturday, April 18th 2020 at Excel Jewellers Guildford Upper Level, 10355 152 St #2203, Surrey, BC V3R 7C1</div>
<div>For more information visit <b><a style="color:rgba(214, 13, 140);text-decoration:none;" href="https://www.exceljewellers.com/">Exceljewellers.com</a></b> or <b><a style="color:rgba(214, 13, 140);text-decoration:none;" href="https://www.exceljewellers.com/contact">Contact Us</a></b></div>
<br>
@endif

<div class="logo"><img style="width:250px;" src="https://www.exceljewellers.com/storage/image/page_img/excel_logo.png"></div>

</div>
<div>

</div>
</div>