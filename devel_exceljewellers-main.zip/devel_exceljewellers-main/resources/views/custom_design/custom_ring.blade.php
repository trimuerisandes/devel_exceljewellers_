@extends('layouts.web')

@section('include')

@endsection

@section('main')
	<div class="custom-ring-container">
		
	</div>
	<style type="text/css">
		
		.custom-ring-container{
			max-width: 1000px;
			margin: auto;
		}

	</style>
@endsection