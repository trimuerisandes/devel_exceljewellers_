<!-- <style type="text/css">	
@import url('https://fonts.googleapis.com/css?family=Open+Sans&display=swap');
*{font-family: 'Open Sans', sans-serif;}body{background:white;}@font-face {font-family: 'icomoon';src:url('{{asset('/fonts/icomoon.eot?1zr94m')}}');src:url('{{asset('/fonts/icomoon.eot?1zr94m#iefix')}}') format('embedded-opentype'),url('{{asset('/fonts/icomoon.ttf?1zr94m')}}') format('truetype'),url('{{asset('/fonts/icomoon.woff?1zr94m')}}') format('woff'),url('{{asset('/fonts/icomoon.svg?1zr94m#icomoon')}}') format('svg');font-weight: normal;font-style: normal;}

[class^="icon-"], [class*=" icon-"] {
  /* use !important to prevent issues with browser extensions that change fonts */
  font-family: 'icomoon' !important;
  speak: never;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;

  /* Better Font Rendering =========== */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.icon-degrees-_2_-copy:before {
  content: "\e900";
}
.icon-degrees:before {
  content: "\e901";
}
.icon-diamond-ring:before {
  content: "\e902";
}
.icon-asscher:before {
  content: "\e903";
}
.icon-baguette:before {
  content: "\e904";
}
.icon-cushion:before {
  content: "\e905";
}
.icon-emerald:before {
  content: "\e906";
}
.icon-heart:before {
  content: "\e907";
}
.icon-marquise:before {
  content: "\e908";
}
.icon-moon:before {
  content: "\e909";
}
.icon-oval:before {
  content: "\e90a";
}
.icon-pear:before {
  content: "\e90b";
}
.icon-princess:before {
  content: "\e90c";
}
.icon-radiant:before {
  content: "\e90d";
}
.icon-round:before {
  content: "\e90e";
}
.icon-square:before {
  content: "\e90f";
}
.icon-trapezoid:before {
  content: "\e910";
}
.icon-locked:before {
  content: "\e911";
}
.icon-keyboard_arrow_up:before {
  content: "\e912";
}
.icon-keyboard_arrow_down:before {
  content: "\e913";
}
.icon-cart:before {
  content: "\e914";
}
.icon-mail-envelope-closed:before {
  content: "\e915";
}
.icon-menu:before {
  content: "\e916";
}
.icon-close:before {
  content: "\e917";
}
.icon-education:before {
  content: "\e918";
}
.icon-logout:before {
  content: "\e919";
}
.icon-user:before {
  content: "\e91a";
}
.icon-chevron-down:before {
  content: "\e91b";
}
.icon-phone:before {
  content: "\e91c";
}
.icon-diamond:before {
  content: "\e91d";
}
.icon-search:before {
  content: "\e91e";
}
.icon-untitled:before {
  content: "\e91f";
}
.icon-untitled1:before {
  content: "\e920";
}
.icon-untitled2:before {
  content: "\e921";
}
.icon-Alternative-01:before {
  content: "\e922";
}
.icon-Anniversary-01:before {
  content: "\e923";
}
.icon-Bangle-Bracelet-01:before {
  content: "\e924";
}
.icon-Bar-01:before {
  content: "\e925";
}
.icon-Chain-bracelet-01:before {
  content: "\e926";
}
.icon-Charm-Bracelet-01:before {
  content: "\e927";
}
.icon-Choker-01:before {
  content: "\e928";
}
.icon-Classic-01:before {
  content: "\e929";
}
.icon-Cuff-Bracelet-01:before {
  content: "\e92a";
}
.icon-Curved-01:before {
  content: "\e92b";
}
.icon-Diamond-Ring-01:before {
  content: "\e92c";
}
.icon-Diamond-01:before {
  content: "\e92d";
}
.icon-Double-Halo-01:before {
  content: "\e92e";
}
.icon-Drops-01:before {
  content: "\e92f";
}
.icon-Eternity-01:before {
  content: "\e930";
}
.icon-Fashion-01:before {
  content: "\e931";
}
.icon-Free-Form-01:before {
  content: "\e932";
}
.icon-Gem-Stone-Ring-01:before {
  content: "\e933";
}
.icon-Halo-01:before {
  content: "\e934";
}
.icon-Heart-Necklace-01:before {
  content: "\e935";
}
.icon-Heart-01:before {
  content: "\e936";
}
.icon-Hoops-01:before {
  content: "\e937";
}
.icon-Huggies-01:before {
  content: "\e938";
}
.icon-Jacket-01:before {
  content: "\e939";
}
.icon-Locket-01:before {
  content: "\e93a";
}
.icon-Lux-01:before {
  content: "\e93b";
}
.icon-Pave-01:before {
  content: "\e93c";
}
.icon-Pearl-Ring-01:before {
  content: "\e93d";
}
.icon-Ring-Setting-01:before {
  content: "\e93e";
}
.icon-Solitare-01:before {
  content: "\e93f";
}
.icon-Split-Shank-01:before {
  content: "\e940";
}
.icon-Stackable-01:before {
  content: "\e941";
}
.icon-Straight-01:before {
  content: "\e942";
}
.icon-Studs-01:before {
  content: "\e943";
}
.icon-Tennis-Bracelet-01:before {
  content: "\e944";
}
.icon-Three-Stone-01:before {
  content: "\e945";
}
.icon-Y-Knots-01:before {
  content: "\e946";
}
.icon-clipboard:before {
  content: "\e947";
}
.icon-heart-o:before {
  content: "\e948";
}
.icon-trillion-1:before {
  content: "\e949";
}
.icon-cog:before {
  content: "\e994";
}
.icon-hammer:before {
  content: "\e996";
}
.icon-truck:before {
  content: "\e9b0";
}
.icon-star-empty:before {
  content: "\e9d7";
}
.icon-play:before {
  content: "\ea15";
}
.icon-ring:before {
  content: "\ea56";
}
.icon-facebook:before {
  content: "\ea90";
}
.icon-instagram:before {
  content: "\ea92";
}
.icon-twitter:before {
  content: "\ea96";
}
.icon-youtube:before {
  content: "\ea9d";
}
.icon-linkedin2:before {
  content: "\eaca";
}
.icon-pinterest2:before {
  content: "\ead2";
}

</style> -->