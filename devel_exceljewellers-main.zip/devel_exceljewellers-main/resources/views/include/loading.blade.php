<!-- <div class="loading">
	<div class="spin-diamond-container">
		<img id="spin-diamond" src="{{asset('storage/image/page_img/loader.svg')}}">
		<div id="load-text">Loading...</div>
	</div>
</div> -->

<!-- <style type="text/css">
	
	.loading{
		position: fixed;
		top: 50%;
	    left: 50%;
	    transform: translate(-50%, -50%);
		width: 100%;
		height: 100%;
		background: white;
		z-index: 1001;
		color: #d60d8c;
	}

	.spin-diamond-container{
		position: fixed;
		top: 50%;
	    left: 50%;
	    transform: translate(-50%, -50%);
	}

	#load-text{
		position: fixed;
		top: 50%;
	    left: 50%;
	    transform: translate(-15%, 200%);
	}

	#spin-diamond{
		padding: 100px;
		-webkit-animation: spin 1.5s linear infinite; /* Safari */
  		animation: spin 1.5s linear infinite;

	}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@keyframes #spin-diamond {
    0% {
        transform: translate3d(-50%, -50%, 0) rotate(0deg);
    }
    100% {
         transform: translate3d(-50%, -50%, 0) rotate(360deg);
    }
}

</style> -->