<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div id='diamondinstantinventory' data-apikey='572f8749-074b-49b4-8999-287eaaf1e182' height='100%' width='100%'></div> <script src='https://instantinventory-widgets-cl59s.s3.amazonaws.com/diamonds/1.0.0/widget.js'></script> 

</body>
</html>