<div class="size-container">
    <div>Size:</div>
    <ul>
        <li class="size-btn">S</li>
        <li class="size-btn">M</li>
        <li class="size-btn">L</li>
        <li class="size-btn">XL</li>
        <li class="size-btn">XLL</li>
    </ul>
</div>