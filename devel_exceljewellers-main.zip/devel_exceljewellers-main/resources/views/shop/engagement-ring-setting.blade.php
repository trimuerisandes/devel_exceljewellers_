@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Diamond Engagement Rings Style Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own &amp; Explore Our Diamond Engagement Ring Styles &amp; Settings.Shop from 14k White Gold To Solitaire At Excel Jewellers Canada
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring">
@endsection

@section('title')
DIAMOND ENGAGEMENT RING
@endsection