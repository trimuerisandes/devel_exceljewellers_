@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Moissanite Diamond Jewelry Rings Heart Arrow Canada
@endsection

@section('page-description')
Shop Our Heart Arrow Forever One Moissanite Brilliant Cut Diamond Stones.Shop Forever Brilliant Moissanite Rings Engagement Rings Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite">
@endsection

@section('title')
SHOP MOISSANITE BRILLIANT CUT
@endsection