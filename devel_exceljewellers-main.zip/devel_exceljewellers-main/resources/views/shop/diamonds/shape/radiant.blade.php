@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Radiant Shape Diamond Stone Certified Surrey Canada
@endsection

@section('page-description')
Shop Radiant Cut Shape Style Mined Diamond Gemstone. Create Your Radiant Engagement Rings With Our Quality Loose Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=radiant">
@endsection

@section('title')
RADIANT SHAPE MINED DIAMONDS
@endsection