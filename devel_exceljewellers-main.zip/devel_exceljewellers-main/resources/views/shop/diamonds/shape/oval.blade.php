@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Oval Cut Shape Diamond Stone Certified Surrey Canada
@endsection

@section('page-description')
Shop Oval Cut Shape Style Mined Diamond Gemstones.Create Your Oval Engagement Ring With Our High Quality Mined Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=oval">
@endsection

@section('title')
OVAL SHAPE MINED DIAMONDS
@endsection