@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Emerald Shape Diamond Stone Certified Surrey Canada
@endsection

@section('page-description')
Shop Emerald Cut Shape Style Mined Diamond Gemstone. Create Your Emerald Engagement Rings With Our High Quality Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=emerald">
@endsection

@section('title')
EMERALD SHAPE MINED DIAMONDS
@endsection