@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Square Shape Diamond Loose Stone Certified Canada
@endsection

@section('page-description')
Shop Square Cut Shape Style Mined Diamond Gemstone. Create Your Princess Engagement Rings With Our Quality Loose Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=square">
@endsection

@section('title')
SQUARE SHAPE MINED DIAMONDS
@endsection