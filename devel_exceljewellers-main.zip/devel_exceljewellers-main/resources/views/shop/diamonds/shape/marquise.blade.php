@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Marquise Shape Diamond Stone Certified Surrey Canada
@endsection

@section('page-description')
Shop Marquise Cut Shape Style Mined Diamond Gemstones.Create Your Marquise Engagement Ring With Our High Quality Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=marquise">
@endsection

@section('title')
MARQUISE SHAPE MINED DIAMONDS
@endsection