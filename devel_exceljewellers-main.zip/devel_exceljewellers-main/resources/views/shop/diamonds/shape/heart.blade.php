@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Heart Shape Diamond Stone Certified Surrey Canada
@endsection

@section('page-description')
Shop Heart Cut Shape Style Mined Diamond Gemstone. Create Your Heart Engagement Rings With Our High Quality Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=heart">
@endsection

@section('title')
HEART SHAPE MINED DIAMONDS
@endsection