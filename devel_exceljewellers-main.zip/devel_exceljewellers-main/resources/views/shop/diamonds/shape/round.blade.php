@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Round Shape Diamond Loose Stone Certified Canada
@endsection

@section('page-description')
Shop Round Cut Shape Style Mined Diamond Gemstone. Create Your Heart Engagement Rings With Our Quality Loose Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds?shape=round">
@endsection

@section('title')
ROUND SHAPE MINED DIAMONDS
@endsection