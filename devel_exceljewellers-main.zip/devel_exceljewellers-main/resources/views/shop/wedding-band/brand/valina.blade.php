@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Valina Diamond Wedding Band Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Valina Women Wedding Band Ring Set. Shop Valina rings From 14K Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey Burnaby
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=valina">
@endsection

@section('title')
VALINA WEDDING BAND
@endsection