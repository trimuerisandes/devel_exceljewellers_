@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Romance Diamond Wedding Band Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Romance Women Wedding Band Ring Set. Shop Romance rings From 14K Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey Burnaby
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=romance">
@endsection

@section('title')
ROMANCE WEDDING BAND
@endsection