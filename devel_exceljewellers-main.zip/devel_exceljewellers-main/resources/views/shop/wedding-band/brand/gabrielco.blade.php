@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Gabriel & Co Diamond Wedding Band Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Gabriel & Co Wedding Band Ring Set. Shop Gabriel & Co rings From 14K Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey 
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=gabrielco">
@endsection

@section('title')
GABRIEL & CO WEDDING BAND
@endsection