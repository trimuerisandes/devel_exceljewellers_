@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Simon G. Diamond Wedding Band Rings Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Simon G. Womens/Mens Wedding Band Ring Sets. Shop Simon G. Wedding Rings From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=simong">
@endsection

@section('title')
SIMON G. WEDDING BAND
@endsection