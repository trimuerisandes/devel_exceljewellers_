@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Verragio Diamond Wedding Band Rings Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Verragio Womens/Mens Wedding Band Ring Sets. Shop Verragio Wedding Rings From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=verragio">
@endsection

@section('title')
VERRAGIO WEDDING BAND
@endsection