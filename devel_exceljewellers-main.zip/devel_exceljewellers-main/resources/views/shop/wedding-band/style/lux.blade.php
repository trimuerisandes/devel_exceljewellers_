@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Men Lux Diamond Wedding Band Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Men Lux Diamond Wedding Band Set.Shop Lux Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=lux">
@endsection

@section('title')
MENS LUX BAND
@endsection