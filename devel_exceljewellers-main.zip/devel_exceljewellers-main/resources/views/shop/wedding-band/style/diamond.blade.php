@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Men Diamond Wedding Band Ring Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Men Diamond Wedding Band Ring Set.Shop Men Diamond Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey Burnaby
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=men%20diamond">
@endsection

@section('title')
MENS DIAMOND BAND
@endsection