@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Women Eternity Diamond Wedding Band Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Women Eternity Diamond Wedding Band Ring Set.Shop Eternity Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=eternity">
@endsection

@section('title')
WOMENS ETERNITY BAND
@endsection