@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Women Anniversary Diamond Wedding Band Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Women Anniversary Diamond Wedding Band Set.Shop Anniversary Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=anniversary">
@endsection

@section('title')
MENS ANNIVERSARY BAND
@endsection