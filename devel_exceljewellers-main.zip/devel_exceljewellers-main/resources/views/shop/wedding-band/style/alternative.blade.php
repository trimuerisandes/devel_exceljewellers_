@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Men Alternative Diamond Wedding Band Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Men Alternative Diamond Wedding Band Set.Shop Alternative Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=alternative">
@endsection

@section('title')
MENS ALTERNATIVE BAND
@endsection