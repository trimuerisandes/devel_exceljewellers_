@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Men Wedding Diamond Wedding Band Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Men Wedding Diamond Wedding Band Ring Set.Shop Men Wedding Band Ring From Yellow White Rose Gold - Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=men%20classic">
@endsection

@section('title')
MENS CLASSIC BAND
@endsection