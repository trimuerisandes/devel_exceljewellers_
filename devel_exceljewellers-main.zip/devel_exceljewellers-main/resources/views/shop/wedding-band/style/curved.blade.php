@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Women Curved Diamond Wedding Band Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Women Curved Diamond Wedding Band Set.Shop Curved Bands Rings From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey Burnaby
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=curved">
@endsection

@section('title')
WOMENS CURVED BAND
@endsection