@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Women Jacket Diamond Wedding Band Excel Jewellers Surrey
@endsection

@section('page-description')
Explore Our Women Jacket Diamond Wedding Band Ring Set.Shop Women Jacket Band From Yellow White Rose Gold To Platinum At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band?category=jacket">
@endsection

@section('title')
WOMENS JACKET BAND
@endsection