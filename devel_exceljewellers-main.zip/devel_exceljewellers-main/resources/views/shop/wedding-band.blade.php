@extends('layouts.weddingband')

@section('include')

@endsection

@section('page-title')
Diamond Wedding Band Ring Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Wedding Band Rings.Shop Diamond Wedding Band from 14k White Yellow Rose Gold To Curved At Excel Jewellers Surrey Langley Burnaby Canada
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/wedding-band">
@endsection

@section('title')
DIAMOND WEDDING BAND
@endsection