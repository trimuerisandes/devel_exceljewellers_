@extends('layouts.finejewellery')

@section('include')

@endsection

@section('page-title')
Gold Diamond Y Knots Necklaces Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Y Knots Necklaces.Shop Y Knots Necklace From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=y%20knots&category=necklaces">
@endsection

@section('title')
Y-KNOT NECKLACE
@endsection