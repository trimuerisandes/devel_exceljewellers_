@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Locket Necklaces Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Locket Necklaces.Shop Locket Necklace From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/locket&category=necklaces">
@endsection

@section('title')
LOCKET NECKLACE
@endsection