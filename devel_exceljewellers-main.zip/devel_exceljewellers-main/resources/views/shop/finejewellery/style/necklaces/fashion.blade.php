@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Fashion Necklaces Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Fashion Necklaces.Shop Fashion Necklace From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=fashion&category=necklaces">
@endsection

@section('title')
FASHION NECKLACE
@endsection