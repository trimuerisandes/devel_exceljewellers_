@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Choker Necklaces Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Choker Necklaces.Shop Choker Necklace From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=Choker&category=necklaces">
@endsection

@section('title')
CHOKER NECKLACE
@endsection