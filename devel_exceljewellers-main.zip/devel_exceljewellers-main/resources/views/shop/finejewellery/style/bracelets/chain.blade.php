@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Chain Bracelet Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Chain Bracelet Set.Shop Chain Bracelet From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Guildford
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=chain&category=bracelet">
@endsection

@section('title')
CHAIN BRACELET
@endsection