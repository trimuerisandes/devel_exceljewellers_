@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Earrrings Men Women Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Earrrings. Shop Gemstone Pearl Earrrings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver.
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=earrings">
@endsection

@section('title')
EARRINGS
@endsection