@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Womens Gold Diamond Necklaces Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Necklaces.Shop Gemstone Necklaces From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=necklaces">
@endsection

@section('title')
NECKLACES
@endsection