@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Diamond Fashion Rings Excel Jewellers Surrey Langley Canada
@endsection

@section('page-description')
Explore Our Diamond Fashion Rings.Shop Diamond Gemstone Rings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=rings&style=Diamond">
@endsection

@section('title')
DIAMOND RING
@endsection