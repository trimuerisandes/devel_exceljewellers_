@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Diamond Pearl Fashion Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Pearl Fashion Rings.Shop Black Pearl Rings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=rings&style=Pearl">
@endsection

@section('title')
PEARL RING
@endsection