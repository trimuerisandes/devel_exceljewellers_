@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Gemstone Fashion Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gemstone Fashion Rings.Shop Pearl Sapphire Ruby Emerald Amethyst Peridot Rings From At Excel Jewellers Canada Langley Surrey Burnaby Vancouver Abbotsford
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=rings&style=Gemstone">
@endsection

@section('title')
GEMSTONE COLOR RING
@endsection