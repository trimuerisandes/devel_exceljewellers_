@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Fashion Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Fashion Rings.Shop Pearl Gemstone Rings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?category=rings">
@endsection

@section('title')
RINGS
@endsection