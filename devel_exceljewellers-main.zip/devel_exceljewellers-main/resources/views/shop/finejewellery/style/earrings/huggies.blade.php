@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Huggies Earrrings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Huggies Earrrings. Shop Huggies Earrrings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=huggies&category=earrings">
@endsection

@section('title')
HUGGIES EARRINGS
@endsection