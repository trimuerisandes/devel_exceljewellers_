@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Studs Earrrings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Studs Earrrings. Shop Studs Earrrings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=drop&category=earrings">
@endsection

@section('title')
STUD EARRINGS
@endsection