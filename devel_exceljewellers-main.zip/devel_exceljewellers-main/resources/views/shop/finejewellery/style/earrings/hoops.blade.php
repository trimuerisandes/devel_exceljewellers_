@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Hoops Earrrings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Hoops Earrrings. Shop Hoops Earrrings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=hoops&category=earrings">
@endsection

@section('title')
HOOP EARRINGS
@endsection