@extends('layouts.finejewellery')


@section('include')

@endsection

@section('page-title')
Gold Diamond Drop Earrrings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Gold Diamond Drop Earrrings. Shop Drop Earrrings From Yellow White Rose Gold At Excel Jewellers Canada Langley Surrey Burnaby Abbotsford Vancouver.
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery?style=drop&category=earrings">
@endsection

@section('title')
DROP EARRINGS
@endsection