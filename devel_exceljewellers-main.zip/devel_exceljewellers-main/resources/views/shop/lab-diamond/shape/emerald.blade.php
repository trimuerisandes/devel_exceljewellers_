@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Emerald Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Emerald Cut Shape Style Lab Grown Diamond Gemstone.Create Your Emerald Engagement Rings With Man Made Lab Grown Lab Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=emerald">
@endsection

@section('title')
EMERALD SHAPE LAB GROWN DIAMOND
@endsection