@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Round Shape Cut Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Round Cut Shape Style Lab Grown Diamond Gemstones.Create Your Round Engagement Ring With Our Man Made Lab Grown Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=round">
@endsection

@section('title')
ROUND SHAPE LAB GROWN DIAMOND
@endsection