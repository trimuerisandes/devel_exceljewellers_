@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Oval Shape Cut Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Oval Cut Shape Style Lab Grown Diamond Gemstones.Create Your Oval Engagement Rings With Man Made Lab Grown Lab Made Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=oval">
@endsection

@section('title')
OVAL SHAPE LAB GROWN DIAMOND
@endsection