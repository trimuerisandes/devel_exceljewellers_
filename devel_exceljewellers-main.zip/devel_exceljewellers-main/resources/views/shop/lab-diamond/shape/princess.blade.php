@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Princess Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Princess Cut Shape Style Lab Grown Diamond Gemstones.Create Your Princess Engagement Rings With Man Made Lab Grown Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=princess">
@endsection

@section('title')
PRINCESS SHAPE LAB GROWN DIAMOND
@endsection