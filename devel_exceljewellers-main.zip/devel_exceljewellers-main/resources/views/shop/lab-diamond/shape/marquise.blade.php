@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Marquise Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Marquise Cut Shape Style Lab Grown Diamond Gemstones.Create Your Marquise Engagement Rings With Man Made Lab Grown Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=marquise">
@endsection

@section('title')
MARQUISE SHAPE LAB GROWN DIAMOND
@endsection