@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Cushion Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Cushion Cut Shape Style Lab Grown Diamond Gemstones.Create Your Cushion Engagement Rings With Man Made Lab Grown Lab Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=cushion">
@endsection

@section('title')
CUSHION SHAPE LAB GROWN DIAMOND
@endsection