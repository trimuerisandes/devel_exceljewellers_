@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Radiant Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Radiant Cut Shape Style Lab Grown Diamond Gemstone.Create Your Radiant Engagement Rings With Man Made Lab Grown Lab Gemstone Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=radiant">
@endsection

@section('title')
RADIANT SHAPE LAB GROWN DIAMOND
@endsection