@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Asscher Shape Lab Grown Diamond Certified Langley Surrey Canada
@endsection

@section('page-description')
Shop Asscher Cut Shape Style Lab Grown Diamond Gemstones.Create Your Asscher Engagement Rings With Man Made Lab Grown Lab Gemstones Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond?shape=asscher">
@endsection

@section('title')
ASSCHER SHAPE LAB GROWN DIAMOND
@endsection