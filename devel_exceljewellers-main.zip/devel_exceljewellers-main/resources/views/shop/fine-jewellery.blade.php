@extends('layouts.finejewellery')

@section('include')

@endsection

@section('page-title')
Women Diamond Fine Jewellery Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Explore Our Diamond Fine Jewellery For Men/Women.Shop Gemstone Pearl Fine Jewellery from White Yellow Rose Gold At Excel Jewellers Surrey Langley Burnaby Canada
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/fine-jewellery">
@endsection

@section('title')
FINE JEWELLERY
@endsection