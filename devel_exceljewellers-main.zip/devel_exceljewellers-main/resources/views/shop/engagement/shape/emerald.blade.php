@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Shop Emerald Shape Diamond Gold Engagement Rings Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Emerald Diamond Engagement Ring & Settings. Emerald Shape Head Style From 14K White Gold Rose At Excel Jewellers Canada Vancouver Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?shape=emerald">
@endsection