@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Shop Cushion Shape Diamond Gold Engagement Rings Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Cushion Diamond Engagement Ring & Settings. Cushion Shape Head Style From 14K White Gold Rose At Excel Jewellers Canada Vancouver Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?shape=cushion">
@endsection