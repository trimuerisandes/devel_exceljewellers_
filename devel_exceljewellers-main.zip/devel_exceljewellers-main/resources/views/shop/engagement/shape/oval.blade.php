@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Shop Oval Shape Style Diamond Gold Engagement Ring Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Oval Diamond Engagement Ring & Settings. Oval Shape Style Head From 14K White Gold Rose At Excel Jewellers Canada Vancouver Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?shape=oval">
@endsection