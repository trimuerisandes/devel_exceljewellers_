@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Shop Princess Shape Diamond Gold Engagement Ring Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Princess Diamond Engagement Ring & Settings. Princess Shape Style From 14K White Gold Rose At Excel Jewellers Canada Vancouver Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?shape=princess">
@endsection