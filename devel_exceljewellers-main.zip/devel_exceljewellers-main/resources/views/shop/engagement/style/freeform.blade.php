@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Free Form Diamond Engagement Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Create Your Own & Explore Our Free Form Diamond Engagement Ring & Settings.Shop Free Form Rings From 14K White - Rose At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=free%20Form">
@endsection

@section('title')
FREE FORM ENGAGEMENT RING
@endsection