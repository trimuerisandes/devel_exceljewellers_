@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Halo Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own &amp; Explore Our Halo Diamond Engagement Ring &amp; Settings.Shop Halo rings from 14k White To Yellow Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=halo">
@endsection

@section('title')
HALO ENGAGEMENT RING
@endsection