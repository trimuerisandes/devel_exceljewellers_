@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Straight Diamond Engagement Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Create Your Own & Explore Our Straight Diamond Engagement Ring & Settings. Shop Straight Rings From 14K White To Rose At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=straight">
@endsection

@section('title')
STRAIGHT ENGAGEMENT RING
@endsection