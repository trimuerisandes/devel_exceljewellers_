@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Three-Stone Diamond Engagement Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Create Your Own & Explore Our Three-Stone Diamond Engagement Ring & Settings. Shop Three-Stone Rings From 14K White At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=three-stone">
@endsection

@section('title')
THREE-STONE ENGAGEMENT RING
@endsection