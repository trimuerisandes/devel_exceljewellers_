@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Split Shank Diamond Engagement Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Create Your Own & Explore Our Split Shank Diamond Engagement Ring & Settings. Shop Split Shank Rings From 14K White At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=split%20shank">
@endsection

@section('title')
SPLIT SHANK ENGAGEMENT RING
@endsection