@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Solitaire Diamond Engagement Ring Excel Jewellers Surrey
@endsection

@section('page-description')
Create Your Own & Explore Our Solitaire Diamond Engagement Ring & Settings.Shop Solitaire Rings From 14K White - Rose At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=solitaire">
@endsection

@section('title')
SOLITAIRE ENGAGEMENT RING
@endsection