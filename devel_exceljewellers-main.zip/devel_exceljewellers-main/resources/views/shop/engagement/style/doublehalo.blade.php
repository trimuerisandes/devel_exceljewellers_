@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Double Halo Diamond Engagement Ring Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own Explore Our Double Halo Diamond Engagement Ring & Settings.Shop Double Halo rings From 14K White Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=double%20halo">
@endsection

@section('title')
DOUBLE HALO ENGAGEMENT RING
@endsection