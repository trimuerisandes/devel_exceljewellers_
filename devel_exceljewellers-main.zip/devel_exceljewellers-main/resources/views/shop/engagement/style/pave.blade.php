@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Pave Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own &amp; Explore Our Pave Diamond Engagement Ring &amp; Settings.Shop Pave rings from 14k White To Yellow Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=pave">
@endsection

@section('title')
PAVE ENGAGEMENT RING
@endsection