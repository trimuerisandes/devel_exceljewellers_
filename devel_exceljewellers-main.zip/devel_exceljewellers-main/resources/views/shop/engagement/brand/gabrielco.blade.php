@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Gabriel&Co Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own Explore Our Gabriel & Co Diamond Engagement Ring & Settings.Shop Gabriel & Co rings From 14K White Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=gabrielco">
@endsection

@section('title')
GABRIEL & CO ENGAGEMENT RING
@endsection