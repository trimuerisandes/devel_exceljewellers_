@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Valina Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own Explore Our Valina Diamond Engagement Ring & Settings.Shop Valina Rings From 14K White Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=valina">
@endsection

@section('title')
VALINA ENGAGEMENT RING
@endsection