@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Simon G. Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Simon G. Diamond Engagement Ring With Our Diamonds. Shop Simon G. Setting 14K White To Yellow Gold At Excel Jewellers Canada Surrey Langley
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=simong">
@endsection

@section('title')
SIMON G. ENGAGEMENT RING
@endsection