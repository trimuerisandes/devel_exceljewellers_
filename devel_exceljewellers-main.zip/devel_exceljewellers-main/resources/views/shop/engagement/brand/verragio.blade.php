@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Verragio Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Shop & Create Your Own Verragio Diamond Engagement Ring With Our Diamonds. Shop Verragio Setting 14K White To Yellow Gold At Excel Jewellers Canada Surrey Langley
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=verragio">
@endsection

@section('title')
VERRAGIO ENGAGEMENT RING
@endsection