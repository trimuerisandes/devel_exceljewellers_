@extends('layouts.engagement')

@section('include')

@endsection

@section('page-title')
Romance Diamond Engagement Rings Excel Jewellers Surrey Canada
@endsection

@section('page-description')
Create Your Own Explore Our Romance Diamond Engagement Ring & Settings.Shop Romance rings From 14K White Gold At Excel Jewellers Canada Langley Surrey
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/engagement-ring?category=romance">
@endsection

@section('title')
ROMANCE ENGAGEMENT RING
@endsection