@extends('layouts.diamonds')

@section('include')

@endsection

@section('page-title')
Shop Mined Shape Diamond Loose Gemstone Certified Surrey Canada
@endsection

@section('page-description')
Shop Our Mined Diamond Loose Gemstone GIA Certified Presented In 360° HD. Create Your Own Engagement Ring With Our Quality Gemstones Canada Surrey Vancouver
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/diamonds">
@endsection

@section('title')
SHOP MINED NATURAL DIAMONDS
@endsection