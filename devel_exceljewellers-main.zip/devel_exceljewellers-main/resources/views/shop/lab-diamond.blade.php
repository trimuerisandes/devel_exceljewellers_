@extends('layouts.lab-diamond')

@section('include')

@endsection

@section('page-title')
Shop Lab Grown Diamond Gemstone Vancouver Langley Surrey Canada
@endsection

@section('page-description')
Shop Lab Grown Diamond Gemstones Professionally Certified. Create Your Own Engagement Ring With Our Lab Grown Man Made Diamonds. Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/lab-grown-diamond">
@endsection

@section('title')
SHOP LAB GROWN DIAMOND
@endsection