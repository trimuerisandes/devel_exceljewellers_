@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Trapezoid Moissanite Diamond Jewelry Surrey Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Trapezoid Cut Shape Style Moissanite Diamond Stones.Forever Brilliant Moissanite Engagement Rings Canada Surrey BC Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=trapezoid">
@endsection

@section('title')
TRAPEZOID BRILLIANT CUT STYLE MOISSANITE
@endsection