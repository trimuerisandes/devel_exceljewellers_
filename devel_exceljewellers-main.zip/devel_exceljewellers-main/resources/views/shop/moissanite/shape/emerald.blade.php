@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Emerald Moissanite Diamond Jewelry Heart Arrow Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Emerald Cut Shape Style Moissanite Diamond Stones.Shop Forever Brilliant Moissanite Engagement Rings Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=emerald">
@endsection

@section('title')
EMERALD BRILLIANT CUT STYLE MOISSANITE
@endsection