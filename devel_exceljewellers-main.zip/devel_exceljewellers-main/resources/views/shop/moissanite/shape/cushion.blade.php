@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Cushion Moissanite Diamond Jewelry Heart Arrow Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Cushion Cut Shape Style Moissanite Diamond Stones.Shop Forever Brilliant Moissanite Engagement Rings Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=cushion">
@endsection

@section('title')
CUSHION BRILLIANT CUT STYLE MOISSANITE
@endsection