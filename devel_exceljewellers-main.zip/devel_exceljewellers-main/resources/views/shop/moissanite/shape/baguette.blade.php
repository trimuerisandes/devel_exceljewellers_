@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Baguette Moissanite Diamond Jewelry Surrey Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Baguette Cut Shape Style Moissanite Diamonds Stones. Forever Brilliant Moissanite Engagement Rings Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=baguette">
@endsection

@section('title')
BAGUETTE BRILLIANT CUT STYLE MOISSANITE
@endsection