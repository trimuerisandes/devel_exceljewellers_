@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Round Moissanite Diamond Jewelry Heart Arrow Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Round Cut Shape Style Moissanite Diamond Stones.Forever Brilliant Moissanite Engagement Rings Canada Surrey BC Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=round">
@endsection

@section('title')
ROUND BRILLIANT CUT STYLE MOISSANITE
@endsection