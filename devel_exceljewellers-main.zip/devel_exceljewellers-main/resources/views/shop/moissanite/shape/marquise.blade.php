@extends('layouts.moissanite')

@section('include')

@endsection

@section('page-title')
Forever One Marquise Moissanite Diamond Jewelry Heart Arrow Canada
@endsection

@section('page-description')
Shop Heart Arrow Forever One Marquise Cut Shape Style Moissanite Diamond Stones. Forever Brilliant Moissanite Engagement Rings Canada Surrey Vancouver Langley USA
@endsection


@section('canonical')
<link rel="canonical" href="https://www.exceljewellers.com/moissanite?shape=marquise">
@endsection

@section('title')
MARQUISE BRILLIANT CUT STYLE MOISSANITE
@endsection